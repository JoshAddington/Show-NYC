from django.test import TestCase
from .models import Campaign